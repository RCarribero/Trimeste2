package Tema7.interfazVehiculos;

public interface vehiculo {
    String estado="";
    boolean estaEnMarcha();
    void arrancar();
    void detener();
}
