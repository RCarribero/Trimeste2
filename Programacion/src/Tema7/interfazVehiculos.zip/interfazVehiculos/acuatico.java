package Tema7.interfazVehiculos;

public interface acuatico extends vehiculo {
void navegar(int distancia);
}
