package Tema7.interfazVehiculos;

public interface terrestre extends vehiculo{
    void conducir(int distancia);
}
