package Tema7.interfaces.Examen;

public interface Programable {
    void programarInicio(String hora);

    void programarParada(String hora);
}
